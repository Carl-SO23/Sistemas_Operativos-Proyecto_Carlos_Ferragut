#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 50000
#define BUFFER_SIZE 4096
#define MAX_LINES 256

char* trim(char* s) {
    char* end;
    while (*s && isspace((unsigned char)*s)) s++;
    if (*s == 0) return s;
    end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return s;
}

int starts_with(const char* str, const char* pref) {
    return strncmp(str, pref, strlen(pref)) == 0;
}

int main() {
    int sockfd, newsockfd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;
    char buffer[BUFFER_SIZE];
    int n;

    // Crear socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Error al abrir el socket");
        exit(1);
    }

    // Preparar direcci�n del servidor
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

    // Asociar socket
    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Error en bind");
        close(sockfd);
        exit(1);
    }

    // Escuchar conexiones
    listen(sockfd, 5);
    printf("Escuchando\n\n");
    fflush(stdout);

    clilen = sizeof(cli_addr);

    while (1) {
        newsockfd = accept(sockfd, (struct sockaddr*)&cli_addr, &clilen);
        if (newsockfd < 0) {
            perror("Error en accept");
            close(sockfd);
            exit(1);
        }

        memset(buffer, 0, BUFFER_SIZE);
        n = read(newsockfd, buffer, BUFFER_SIZE - 1);
        if (n < 0) {
            perror("Error en read");
            close(newsockfd);
            continue;
        }
        buffer[n] = '\0';

        char* lines[MAX_LINES];
        int linecount = 0;
        char* tok = strtok(buffer, "\r\n");
        while (tok != NULL && linecount < MAX_LINES) {
            lines[linecount++] = trim(tok);
            tok = strtok(NULL, "\r\n");
        }

        int handled = 0;
        char jugador[BUFFER_SIZE] = "(desconocido)";

        for (int i = 0; i < linecount && !handled; i++) {
            char* line = lines[i];

            if (strcmp(line, "SE_UNIO") == 0) {
                if (i > 0 && strlen(lines[i - 1]) > 0) strncpy(jugador, lines[i - 1], BUFFER_SIZE - 1);
                else if (i + 1 < linecount && strlen(lines[i + 1]) > 0) strncpy(jugador, lines[i + 1], BUFFER_SIZE - 1);
                printf("Jugador conectado: %s\n\n", jugador);
                fflush(stdout);
                handled = 1;
                break;
            }
            else if (starts_with(line, "SE_UNIO ")) {
                strncpy(jugador, trim(line + strlen("SE_UNIO ")), BUFFER_SIZE - 1);
                printf("Jugador conectado: %s\n\n", jugador);
                fflush(stdout);
                handled = 1;
                break;
            }
            else if (strcmp(line, "JUGADA") == 0 || starts_with(line, "JUGADA ")) {
                char jugada[BUFFER_SIZE] = "";
                if (starts_with(line, "JUGADA ")) {
                    strncpy(jugada, trim(line + strlen("JUGADA ")), BUFFER_SIZE - 1);
                }
                else if (i + 1 < linecount) {
                    strncpy(jugada, lines[i + 1], BUFFER_SIZE - 1);
                }
                printf("Jugada: %s\n\n", jugada);
                fflush(stdout);
                handled = 1;
                break;
            }
            else if (strcmp(line, "FIN_PARTIDA") == 0 || starts_with(line, "FIN_PARTIDA")) {
                printf("Fin de partida recibido del cliente\n\n");
                fflush(stdout);
                handled = 1;
                break;
            }
            else if (strcmp(line, "CONSULTA_GANADOR") == 0 || strcmp(line, "CONSULTA") == 0) {
                for (int j = i + 1; j < linecount; j++) {
                    if (starts_with(lines[j], "Ganador:")) {
                        char* val = trim(lines[j] + strlen("Ganador:"));
                        printf("Ganador: %s\n\n", val);
                        fflush(stdout);
                        break;
                    }
                }
                handled = 1;
                break;
            }
            else if (strcmp(line, "CONSULTA_DURACION") == 0 || strcmp(line, "CONSULTA_DUR") == 0) {
                for (int j = i + 1; j < linecount; j++) {
                    if (starts_with(lines[j], "Dur:") || starts_with(lines[j], "Duraci�n:")) {
                        char* pos = strchr(lines[j], ':');
                        if (pos) printf("Duraci�n: %s\n\n", trim(pos + 1));
                        else printf("Duraci�n: %s\n\n", lines[j]);
                        fflush(stdout);
                        break;
                    }
                }
                handled = 1;
                break;
            }
            else if (strcmp(line, "CONSULTA_MOVIMIENTOS") == 0 || strcmp(line, "CONSULTA_MOV") == 0) {
                for (int j = i + 1; j < linecount; j++) {
                    if (starts_with(lines[j], "Mov:") || starts_with(lines[j], "Movimientos:") || starts_with(lines[j], "N�mero de jugadas:")) {
                        char* pos = strchr(lines[j], ':');
                        if (pos) printf("N�mero de jugadas: %s\n\n", trim(pos + 1));
                        else printf("N�mero de jugadas: %s\n\n", lines[j]);
                        fflush(stdout);
                        break;
                    }
                }
                handled = 1;
                break;
            }
            else if (strcmp(line, "MENSAJE") == 0 || starts_with(line, "MENSAJE ")) {
                char msg[BUFFER_SIZE] = "";
                if (starts_with(line, "MENSAJE ")) {
                    strncpy(msg, trim(line + strlen("MENSAJE ")), BUFFER_SIZE - 1);
                }
                else if (i + 1 < linecount) {
                    strncpy(msg, lines[i + 1], BUFFER_SIZE - 1);
                }
                printf("Mensaje de %s: %s\n\n", jugador, msg);
                fflush(stdout);
                handled = 1;
                break;
            }
        }

        close(newsockfd);
    }

    close(sockfd);
    return 0;
}


