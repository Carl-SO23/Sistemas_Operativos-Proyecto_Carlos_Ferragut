﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Project_0
{
    public partial class Form3 : Form
    {
        // Archivo SQLite esperado en la carpeta de ejecución
        private readonly string dbFile = "juego.db";

        // Estado de la partida
        private string playerName = "";
        private int scorePlayer = 0;
        private int scoreMachine = 0;
        private int numeroJugadas = 0; // cuenta todas las rondas (incluye empates)
        private DateTime partidaInicio;

        private readonly Random rng = new Random();

        public Form3()
        {
            InitializeComponent();
            // panelJuego debería venir del Designer; lo dejamos desactivado hasta unirse
            try { panelJuego.Enabled = false; } catch { }
        }

        // Envía trazas al servidor (no bloqueante si falla)
        private void EnviarAlServidor(string mensaje)
        {
            try
            {
                using (TcpClient tcpclnt = new TcpClient("192.168.56.102", 50000))
                {
                    NetworkStream ns = tcpclnt.GetStream();
                    byte[] data = Encoding.ASCII.GetBytes(mensaje);
                    ns.Write(data, 0, data.Length);
                }
            }
            catch
            {
                // Ignoramos errores de red: la app debe seguir funcionando sin servidor.
            }
        }

        // ========================
        // Unirse / iniciar partida
        // ========================
        private void btnJoin_Click(object sender, EventArgs e)
        {
            playerName = txtPlayerName.Text?.Trim() ?? "";
            if (string.IsNullOrEmpty(playerName))
            {
                MessageBox.Show("Introduce un nombre para unirte.");
                return;
            }

            // Inicializar estado de la partida
            partidaInicio = DateTime.Now;
            scorePlayer = 0;
            scoreMachine = 0;
            numeroJugadas = 0;

            // Asegurar que el jugador existe (INSERT OR IGNORE)
            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand("INSERT OR IGNORE INTO Jugadores (nombre) VALUES (@nombre);", conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", playerName);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al asegurar jugador en BD: " + ex.Message);
                return;
            }

            // Activar UI del juego
            try { panelJuego.Enabled = true; } catch { }
            try { lblScore.Text = $"{playerName}: 0 - Máquina: 0"; } catch { }

            EnviarAlServidor($"{playerName}\nSE_UNIO");
        }

        // ========================
        // Jugar una ronda
        // ========================
        private void btnJugar_Click(object sender, EventArgs e)
        {
            // Validaciones básicas
            if (string.IsNullOrEmpty(playerName))
            {
                MessageBox.Show("Debes unirte primero (introduce tu nombre).");
                return;
            }

            try
            {
                if (!panelJuego.Enabled)
                {
                    MessageBox.Show("La partida no está activa.");
                    return;
                }
            }
            catch
            {
                // si panelJuego no existe en diseñador, continuamos (pero idealmente existe)
            }

            // Selección del jugador
            string optionPlayer;
            try
            {
                optionPlayer = comboJugador.SelectedItem?.ToString();
            }
            catch
            {
                MessageBox.Show("Control de selección no encontrado.");
                return;
            }

            if (string.IsNullOrEmpty(optionPlayer))
            {
                MessageBox.Show("Selecciona Piedra, Papel o Tijera.");
                return;
            }

            // Elección del ordenador
            string[] opciones = { "Piedra", "Papel", "Tijera" };
            string optionMachine = opciones[rng.Next(opciones.Length)];

            // Resultado de la ronda
            string resultado;
            if (optionPlayer == optionMachine)
            {
                resultado = $"Empate. Ambos eligieron {optionPlayer}.";
            }
            else if ((optionPlayer == "Piedra" && optionMachine == "Tijera") ||
                     (optionPlayer == "Papel" && optionMachine == "Piedra") ||
                     (optionPlayer == "Tijera" && optionMachine == "Papel"))
            {
                resultado = $"{playerName} gana la ronda. ({optionPlayer} vs {optionMachine})";
                scorePlayer++;
            }
            else
            {
                resultado = $"Máquina gana la ronda. ({optionPlayer} vs {optionMachine})";
                scoreMachine++;
            }

            // Cada ronda cuenta como una jugada (incluye empates)
            numeroJugadas++;

            // Actualizar UI
            try { lblScore.Text = $"{playerName}: {scorePlayer} - Máquina: {scoreMachine}"; } catch { }
            MessageBox.Show(resultado);

            // Guardar la jugada/historial en tabla Messages (no imprescindible para la lógica)
            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand("INSERT INTO Messages (Nombre, Message, Timestamp, Marcador) VALUES (@nombre, @msg, datetime('now'), @marc);", conn))
                    {
                        string texto = $"Jugada: {optionPlayer} vs {optionMachine} -> {resultado}";
                        cmd.Parameters.AddWithValue("@nombre", playerName);
                        cmd.Parameters.AddWithValue("@msg", texto);
                        cmd.Parameters.AddWithValue("@marc", $"{scorePlayer}-{scoreMachine}");
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                // No detenemos la partida por errores en el historial
                MessageBox.Show("Error guardando historial: " + ex.Message);
            }

            // Enviar traza al servidor
            EnviarAlServidor($"{playerName}\nJUGADA\n{optionPlayer} vs {optionMachine} -> {resultado}");

            // Si alguien llega a 3, finalizar
            if (scorePlayer == 3 || scoreMachine == 3)
            {
                FinalizarPartida();
            }
        }

        // ========================
        // Finalizar partida: guardar en BD y mostrar ID al usuario
        // ========================
        private void FinalizarPartida()
        {
            try { panelJuego.Enabled = false; } catch { }

            string ganador = scorePlayer == 3 ? playerName : "Máquina";
            MessageBox.Show($"Partida finalizada. Ganador: {ganador}");

            int duracionSegundos = (int)(DateTime.Now - partidaInicio).TotalSeconds;
            int nuevaPartidaId = 0;

            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();

                    // Asegurar que 'Máquina' exista como jugador para que la subconsulta funcione
                    using (var cmdM = new SQLiteCommand("INSERT OR IGNORE INTO Jugadores (nombre) VALUES ('Máquina');", conn))
                    {
                        cmdM.ExecuteNonQuery();
                    }

                    // Insertar partida (usa numero_jugadas existente en tu esquema)
                    using (var cmd = new SQLiteCommand(@"INSERT INTO Partidas
                        (fecha, duracion_segundos, numero_jugadas, ganador_id)
                        VALUES (datetime('now'), @dur, @jug, (SELECT jugador_id FROM Jugadores WHERE nombre=@ganador));", conn))
                    {
                        cmd.Parameters.AddWithValue("@dur", duracionSegundos);
                        cmd.Parameters.AddWithValue("@jug", numeroJugadas);
                        cmd.Parameters.AddWithValue("@ganador", ganador);
                        cmd.ExecuteNonQuery();
                    }

                    // Obtener id de la partida recien insertada
                    using (var cmd2 = new SQLiteCommand("SELECT last_insert_rowid();", conn))
                    {
                        object o = cmd2.ExecuteScalar();
                        if (o != null && int.TryParse(o.ToString(), out int val)) nuevaPartidaId = val;
                    }

                    // Si tenemos id, insertar relación N:M en JugadorPartida
                    if (nuevaPartidaId > 0)
                    {
                        using (var cmd3 = new SQLiteCommand(@"INSERT OR REPLACE INTO JugadorPartida (jugador_id, partida_id, movimientos)
                            VALUES ((SELECT jugador_id FROM Jugadores WHERE nombre=@nombre), @pid, @mov);", conn))
                        {
                            cmd3.Parameters.AddWithValue("@nombre", playerName);
                            cmd3.Parameters.AddWithValue("@pid", nuevaPartidaId);
                            cmd3.Parameters.AddWithValue("@mov", numeroJugadas);
                            cmd3.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la partida en BD: " + ex.Message);
            }

            // Mostrar al usuario el ID resultante (si es 0 algo falló)
            if (nuevaPartidaId > 0)
            {
                MessageBox.Show($"ID de la partida: {nuevaPartidaId}");
            }
            else
            {
                MessageBox.Show("ID de la partida no disponible (error al guardar).");
            }

            // Enviar traza final
            EnviarAlServidor($"{playerName}\nFIN_PARTIDA\nGanador:{ganador}\nMov:{numeroJugadas}\nDur:{(int)(DateTime.Now - partidaInicio).TotalSeconds}\nID:{nuevaPartidaId}");

            // Recargar historial en UI si existe data grid
            CargarMensajes();
        }

        // ========================
        // Enviar mensaje/chat
        // ========================
        private void btnSend_Click(object sender, EventArgs e)
        {
            string texto = txtMessage.Text?.Trim() ?? "";
            if (string.IsNullOrEmpty(texto))
            {
                MessageBox.Show("Escribe un mensaje antes de enviarlo.");
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand("INSERT INTO Messages (Nombre, Message, Timestamp, Marcador) VALUES (@nombre, @msg, datetime('now'), @marc);", conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", playerName);
                        cmd.Parameters.AddWithValue("@msg", texto);
                        cmd.Parameters.AddWithValue("@marc", $"{scorePlayer}-{scoreMachine}");
                        cmd.ExecuteNonQuery();
                    }
                }

                txtMessage.Text = "";
                CargarMensajes();
                EnviarAlServidor($"{playerName}\nMESSAGE\n{texto}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al enviar mensaje: " + ex.Message);
            }
        }

        // ========================
        // Consultas (ganador / duracion / movimientos)
        // ========================
        // CONSULTAR GANADOR -> ahora **solo** devuelve el nombre del ganador
        private void btnConsultarGanador_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtIdPartida.Text?.Trim(), out int idPartida))
            {
                MessageBox.Show("Introduce un ID válido.");
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand(@"
                        SELECT j.nombre
                        FROM Partidas p
                        LEFT JOIN Jugadores j ON p.ganador_id = j.jugador_id
                        WHERE p.partida_id = @pid
                        LIMIT 1;", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", idPartida);
                        object res = cmd.ExecuteScalar();
                        if (res != null && !Convert.IsDBNull(res))
                        {
                            string ganador = res.ToString();
                            MessageBox.Show($"Ganador: {ganador}");
                            EnviarAlServidor($"{playerName}\nCONSULTA\nID:{idPartida}\nGanador:{ganador}");
                        }
                        else
                        {
                            MessageBox.Show("Partida no encontrada o sin ganador registrado.");
                            EnviarAlServidor($"{playerName}\nCONSULTA\nID:{idPartida}\nNO_ENCONTRADO");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar ganador: " + ex.Message);
            }
        }

        // CONSULTAR DURACION (igual que antes)
        private void btnConsultarDuracion_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtIdPartida.Text?.Trim(), out int idPartida))
            {
                MessageBox.Show("Introduce un ID válido.");
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand("SELECT duracion_segundos FROM Partidas WHERE partida_id = @pid", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", idPartida);
                        object o = cmd.ExecuteScalar();
                        if (o != null && !Convert.IsDBNull(o))
                        {
                            MessageBox.Show($"Duración: {o} segundos");
                            EnviarAlServidor($"{playerName}\nCONSULTA_DUR\nID:{idPartida}\nDur:{o}");
                        }
                        else
                        {
                            MessageBox.Show("Partida no encontrada.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar duración: " + ex.Message);
            }
        }

        // CONSULTAR MOVIMIENTOS -> consulta **siempre** numero_jugadas en Partidas
        private void btnConsultarMovimientos_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtIdPartida.Text?.Trim(), out int idPartida))
            {
                MessageBox.Show("Introduce un ID válido.");
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var cmd = new SQLiteCommand("SELECT numero_jugadas FROM Partidas WHERE partida_id = @pid", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", idPartida);
                        object o = cmd.ExecuteScalar();
                        if (o != null && !Convert.IsDBNull(o))
                        {
                            MessageBox.Show($"Movimientos: {o}");
                            EnviarAlServidor($"{playerName}\nCONSULTA_MOV\nID:{idPartida}\nMov:{o}");
                        }
                        else
                        {
                            MessageBox.Show("Partida no encontrada.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar movimientos: " + ex.Message);
            }
        }

        // ========================
        // Cargar mensajes en el DataGridView
        // ========================
        private void CargarMensajes()
        {
            try
            {
                using (var conn = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    conn.Open();
                    using (var da = new SQLiteDataAdapter("SELECT Nombre, Message, Timestamp, Marcador FROM Messages ORDER BY Id DESC", conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvMessages.DataSource = dt;
                    }
                }
            }
            catch
            {
                // no interrumpimos por fallos al cargar historial
            }
        }
    }
}

