﻿namespace Project_0
{
    partial class Form3
    {
        /// <summary>
        /// Variable del diseñador.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // Controles usados por el formulario
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtPlayerName;
        private System.Windows.Forms.Button btnJoin;
        private System.Windows.Forms.Panel panelJuego;
        private System.Windows.Forms.ComboBox comboJugador;
        private System.Windows.Forms.Button btnJugar;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.DataGridView dgvMessages;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label lblIdLabel;
        private System.Windows.Forms.TextBox txtIdPartida;
        private System.Windows.Forms.Button btnConsultarGanador;
        private System.Windows.Forms.Button btnConsultarDuracion;
        private System.Windows.Forms.Button btnConsultarMovimientos;

        /// <summary>
        /// Libera los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador

        /// <summary>
        /// Inicializa los componentes del formulario.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.lblTitle = new System.Windows.Forms.Label();
            this.txtPlayerName = new System.Windows.Forms.TextBox();
            this.btnJoin = new System.Windows.Forms.Button();
            this.panelJuego = new System.Windows.Forms.Panel();
            this.comboJugador = new System.Windows.Forms.ComboBox();
            this.btnJugar = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.dgvMessages = new System.Windows.Forms.DataGridView();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.lblIdLabel = new System.Windows.Forms.Label();
            this.txtIdPartida = new System.Windows.Forms.TextBox();
            this.btnConsultarGanador = new System.Windows.Forms.Button();
            this.btnConsultarDuracion = new System.Windows.Forms.Button();
            this.btnConsultarMovimientos = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvMessages)).BeginInit();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(240, 20);
            this.lblTitle.Text = "Piedra - Papel - Tijera (Cliente)";
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.Location = new System.Drawing.Point(16, 40);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(180, 20);
            this.txtPlayerName.TabIndex = 0;
            // 
            // btnJoin
            // 
            this.btnJoin.Location = new System.Drawing.Point(210, 37);
            this.btnJoin.Name = "btnJoin";
            this.btnJoin.Size = new System.Drawing.Size(90, 24);
            this.btnJoin.TabIndex = 1;
            this.btnJoin.Text = "Unirse";
            this.btnJoin.UseVisualStyleBackColor = true;
            this.btnJoin.Click += new System.EventHandler(this.btnJoin_Click);
            // 
            // panelJuego
            // 
            this.panelJuego.Location = new System.Drawing.Point(16, 75);
            this.panelJuego.Name = "panelJuego";
            this.panelJuego.Size = new System.Drawing.Size(460, 120);
            this.panelJuego.Enabled = false;
            // 
            // comboJugador
            // 
            this.comboJugador.Location = new System.Drawing.Point(10, 10);
            this.comboJugador.Name = "comboJugador";
            this.comboJugador.Size = new System.Drawing.Size(120, 21);
            this.comboJugador.Items.AddRange(new object[] { "Piedra", "Papel", "Tijera" });
            // 
            // btnJugar
            // 
            this.btnJugar.Location = new System.Drawing.Point(140, 8);
            this.btnJugar.Name = "btnJugar";
            this.btnJugar.Size = new System.Drawing.Size(90, 24);
            this.btnJugar.Text = "Jugar";
            this.btnJugar.UseVisualStyleBackColor = true;
            this.btnJugar.Click += new System.EventHandler(this.btnJugar_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(10, 45);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(150, 13);
            this.lblScore.Text = "Jugador: 0 - Máquina: 0";
            // Añadir controles al panelJuego
            this.panelJuego.Controls.Add(this.comboJugador);
            this.panelJuego.Controls.Add(this.btnJugar);
            this.panelJuego.Controls.Add(this.lblScore);
            // 
            // dgvMessages
            // 
            this.dgvMessages.Location = new System.Drawing.Point(16, 210);
            this.dgvMessages.Name = "dgvMessages";
            this.dgvMessages.Size = new System.Drawing.Size(460, 180);
            this.dgvMessages.ReadOnly = true;
            this.dgvMessages.AllowUserToAddRows = false;
            this.dgvMessages.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(16, 400);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(360, 20);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(390, 397);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(86, 25);
            this.btnSend.Text = "Enviar";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // lblIdLabel
            // 
            this.lblIdLabel.AutoSize = true;
            this.lblIdLabel.Location = new System.Drawing.Point(16, 435);
            this.lblIdLabel.Name = "lblIdLabel";
            this.lblIdLabel.Size = new System.Drawing.Size(80, 13);
            this.lblIdLabel.Text = "ID de la partida:";
            // 
            // txtIdPartida
            // 
            this.txtIdPartida.Location = new System.Drawing.Point(100, 432);
            this.txtIdPartida.Name = "txtIdPartida";
            this.txtIdPartida.Size = new System.Drawing.Size(80, 20);
            // 
            // btnConsultarGanador
            // 
            this.btnConsultarGanador.Location = new System.Drawing.Point(190, 430);
            this.btnConsultarGanador.Name = "btnConsultarGanador";
            this.btnConsultarGanador.Size = new System.Drawing.Size(110, 24);
            this.btnConsultarGanador.Text = "Consultar ganador";
            this.btnConsultarGanador.UseVisualStyleBackColor = true;
            this.btnConsultarGanador.Click += new System.EventHandler(this.btnConsultarGanador_Click);
            // 
            // btnConsultarDuracion
            // 
            this.btnConsultarDuracion.Location = new System.Drawing.Point(310, 430);
            this.btnConsultarDuracion.Name = "btnConsultarDuracion";
            this.btnConsultarDuracion.Size = new System.Drawing.Size(80, 24);
            this.btnConsultarDuracion.Text = "Duración";
            this.btnConsultarDuracion.UseVisualStyleBackColor = true;
            this.btnConsultarDuracion.Click += new System.EventHandler(this.btnConsultarDuracion_Click);
            // 
            // btnConsultarMovimientos
            // 
            this.btnConsultarMovimientos.Location = new System.Drawing.Point(400, 430);
            this.btnConsultarMovimientos.Name = "btnConsultarMovimientos";
            this.btnConsultarMovimientos.Size = new System.Drawing.Size(80, 24);
            this.btnConsultarMovimientos.Text = "Movimientos";
            this.btnConsultarMovimientos.UseVisualStyleBackColor = true;
            this.btnConsultarMovimientos.Click += new System.EventHandler(this.btnConsultarMovimientos_Click);

            // 
            // Form3 (configuración final)
            // 
            this.ClientSize = new System.Drawing.Size(494, 470);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtPlayerName);
            this.Controls.Add(this.btnJoin);
            this.Controls.Add(this.panelJuego);
            this.Controls.Add(this.dgvMessages);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.lblIdLabel);
            this.Controls.Add(this.txtIdPartida);
            this.Controls.Add(this.btnConsultarGanador);
            this.Controls.Add(this.btnConsultarDuracion);
            this.Controls.Add(this.btnConsultarMovimientos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form3";
            this.Text = "Piedra Papel Tijera";

            ((System.ComponentModel.ISupportInitialize)(this.dgvMessages)).EndInit();
        }

        #endregion
    }
}
